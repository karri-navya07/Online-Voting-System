
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


--
-- Database: `poll`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbadministrators`
--

CREATE TABLE IF NOT EXISTS `tbadministrators` (
  `adminid` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `mypassword` varchar(45) NOT NULL,
  PRIMARY KEY (`adminid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbadministrators`
--

INSERT INTO `tbadministrators` (`adminid`, `firstname`, `lastname`, `email`, `mypassword`) VALUES
(1, 'Sanjeev', 'Karra', 'hello@gmail.com', '18503547');

-- --------------------------------------------------------


--
-- Table structure for table `tbcandidates`
--

CREATE TABLE IF NOT EXISTS `tbcandidates` (
  `candidateid` int(5) NOT NULL AUTO_INCREMENT,
  `candidatename` varchar(45) NOT NULL,
  `candidateposition` varchar(45) NOT NULL,
  `candidatecvotes` int(11) NOT NULL,
  PRIMARY KEY (`candidateid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `tbcandidates`
--

INSERT INTO `tbcandidates` (`candidateid`, `candidatename`, `candidateposition`, `candidatecvotes`) VALUES
(1, 'Trump', 'President', 0),
(2, 'BIden', 'President', 0),
(3, 'Mike Pence', 'Vice-President', 0),
(4, 'Kamala Harris', 'Vice-President', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tbmembers`
--

CREATE TABLE IF NOT EXISTS `tbmembers` (
  `memberid` int(5) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `voterid` varchar(45) NOT NULL,
  `mypassword` varchar(45) NOT NULL,
  PRIMARY KEY (`memberid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbmembers`
--

INSERT INTO `tbmembers` (`memberid`, `firstname`, `lastname`, `email`, `voterid`, `mypassword`) VALUES
(1, 'Sanjeev', 'Karra', 'hello@mail.com', '18h71a0503', '18503'),
(2, 'Saidulu', 'Vallamkonda', 'second@mail.com', '18h71a0547', '18547');

-- --------------------------------------------------------

--
-- Table structure for table `tbpositions`
--

CREATE TABLE IF NOT EXISTS `tbpositions` (
  `positionid` int(5) NOT NULL AUTO_INCREMENT,
  `positionname` varchar(45) NOT NULL,
  PRIMARY KEY (`positionid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbpositions`
--

INSERT INTO `tbpositions` (`positionid`, `positionname`) VALUES
(1, 'President'),
(2, 'Vice-President');

