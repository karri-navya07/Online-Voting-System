<?php
				//f your session isn't valid, it returns you to the login screen for protection
				if(empty($_SESSION['adminid'])){
				 	header("location:access-denied.php");
				}
				//Process
				if (isset($_POST['submit']))
				{

					$myFirstName = addslashes( $_POST['firstname'] ); //prevents types of SQL injection
					$myLastName = addslashes( $_POST['lastname'] ); //prevents types of SQL injection
					$myEmail = $_POST['email'];
					$myPassword = $_POST['mypassword'];

					

					$sql = mysqli_query( "INSERT INTO tbAdministrators(firstname, lastname, email, mypassword) VALUES ('$myFirstName','$myLastName', '$myEmail', '$myPassword')" )
					        or die( mysqli_error() );

					die( "A new administrator account has been created." );
				}
				//Process
				if (isset($_GET['id']) && isset($_POST['update']))
				{
					$myId = ( $_GET['id']);
					$myFirstName = ( $_POST['firstname'] ); //prevents types of SQL injection
					$myLastName = ( $_POST['lastname'] ); //prevents types of SQL injection
					$myEmail = $_POST['email'];
					$myPassword = $_POST['password'];

					$sql = mysqli_query( "UPDATE tbAdministrators SET firstname='$myFirstName', lastname='$myLastName', email='$myEmail', mypassword='$myPassword' WHERE adminid = '$myId'" )
					        or die( mysqli_error() );

					die( "An administrator account has been updated." );
				}
			?>
