<?php
// Connection
$connect =mysqli_connect ("localhost","root", "" , "poll")
   or die("Connection failed !!! : ");
 
// For checking if connection is
// successful or not
if ($connect) {
  //  echo "Connected successfully!";
}
else{
echo "Not Connected!";
}
?>